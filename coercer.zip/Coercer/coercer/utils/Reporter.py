#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File name          : Reporter.py
# Author             : Podalirius (@podalirius_)
# Date created       : 17 Jul 2022

class Reporter(object):
    """
    Documentation for class Reporter
    """

    def __init__(self):
        super(Reporter, self).__init__()
